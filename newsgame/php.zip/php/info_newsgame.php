I. Admin
    1. Thiết kế database
    2. Phát triển quản lý danh mục bài viết 
    3. Phát triển quản lý bài viết
    4. Phát triển quản lý danh mục hình ảnh
    5. Phát triển quản lý hình ảnh
    6. Phát triển quản lý danh mục sản phẩm game 
    7. Phát triển quản lý sản phẩm game
    8. Trang tổng quát

II. Frontend
    1. Home
    2. Danh mục bài viết
    3. Chi tiết bài viết
    4. Danh mục hình ảnh
    5. Chi tiết hình ảnh
    6. Danh mục sản phẩm game
    7. Chi tiết sản phẩm game
    8. Đăng nhập, đăng ký, đăng xuất
    9. Trang tổng quát


III. Tối ưu giao diện (UI & UX)
    1. Chia ra từng phần: index.php( menubar, slider_start, content lấy từ file khác, banner_eng footer)
    2. Content: các trang chứa nội dủng riêng biệt home.php, daily_life.php, picture.php, ...
    3. Thêm các content vào index thành trang hoàn chỉnh .
    4. Xử lý phần backend (lấy dữ liệu xuống front end) cũng chia theo từng phần

IV. Đã làm xong 
    1. Cơ sở dữ liệu (hơi ít dữ liệu nên thêm vào news, image, game)
    2. Thêm, xóa, sửa, tìm kiếm CSDL (- image chưa làm)
    3. Sắp xếp bài viết mới nhất, nhiều người xem nhất
    4. Phân trang CSDL phía admin
    5. Menu tự động ở cả 2 phía 
    6. Responsive ở tất cả các trang
    7. Giao diện cần chỉnh sửa lại
    8. Đăng nhập, đăng kí, đăng xuất
    9. Không thể vào phần admintration khi chưa có tài khoản, tài khỏa sai, ...

V. Chưa làm
    1. Thêm, xóa, tìm CSDL trên cùng 1 trang -> kiểm tra lại tất cả = cách thêm vào tất cả dữ liệu
    2. Phân trang được nhưng chuyển trang còn bị lỗi.
        Phân trang làm 1 trang riêng ad_paging_news.php -> sửa lại cho trang đẹp hơn
        Trang ad_news.php chưa link dẫn đến trang riêng ad_paging_news.php
    3. Xóa, sửa comment
    4. Trang hình ảnh làm theo label, input -> click hện ẩn
    5. Word và pptx
    6. Gửi đến email user khi đăng kí


VI. Sau khi hoàn thành
    1. Kiểm tra lại tất cả hệ thống wesite(có lỗi không, giao diện ổn không, dữ liệu đủ chưa)
    2. Kiểm tra lại word, powpoint
    3. Thầy cô có thể hỏi những gì, nên trả lời thế nào cho ổn nếu không biết.
    4. Cần tránh khi thuyết trình
        trong game random xóa từ cuối lên, k xóa lung tung do random là số bất kì nên gặp số k có sẽ bị lỗi
        comment khi đăng nhập chưa vào trang hiện tại muốn comment mà trở về trang mặc định trước đó


VII. Thông tin 
    1. PHP: Chỉ được điều hành bởi máy chủ và trả lời các yêu cầu như nhấp vào liên kết (GET) hoặc gửi biểu mẫu (POST)
    2. PHP chỉ đáp ứng các yêu cầu (GET, POST, PUT, PATCH và DELETE qua $ _REQUEST)
    3. $_GET["page"] -> thanh địa chỉ có biến 'page'

