<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    //$sql = 'SELECT * FROM news';

    if(isset($_POST['searchNews']) == true && $_POST['searchNews'] != ''){
        $sqlSearch = 'SELECT * FROM news WHERE id_news like "%' . $_POST['searchNews'] .'%" or id_categoryNews like "%' . $_POST['searchNews'] .'%"';
        $resultSearch = mysqli_query($conn, $sqlSearch);
    }
    

    $sqlAdminMenu = 'SELECT * FROM adminmenu';
    $resultAdminMenu = mysqli_query($conn, $sqlAdminMenu);


    // thêm dữ liệu vào news
    if(isset($_POST['submitAdd'])){
        //$id_news = $_POST['id_news'];
        $id_categoryNews = $_POST['id_categoryNews'];
        $title_news = $_POST['title_news'];
        $description_news = $_POST['description_news'];
        $content_news = $_POST['content_news'];
        $urlImage_news = $_POST['urlImage_news'];
        $dateCreate_post = $_POST['dateCreate_post'];
        $numberOfReaders_news = $_POST['numberOfReaders_news'];


        if($id_categoryNews == ""){echo '"Image id category" field cannot be empty.';}
        if($title_news == ""){echo '"Image name" field cannot be empty.';}
        if($description_news == ""){echo '"description_news" field cannot be empty.';}
        if($content_news == ""){echo '"content_news" field cannot be empty.';}
        if($urlImage_news == ""){echo '"urlImage_news" field cannot be empty.';}
        if($dateCreate_post == ""){echo '"dateCreate_post" field cannot be empty.';}
        if($numberOfReaders_news == ""){echo '"numberOfReaders_news" field cannot be empty.';}


        $sqlAdd = "INSERT INTO news(id_news, id_categoryNews, title_news, description_news, content_news, urlImage_news, dateCreate_post, numberOfReaders_news) 
        VALUES('', '$id_categoryNews', '$title_news', '$description_news', '$content_news', '$urlImage_news', '$dateCreate_post', '$numberOfReaders_news')";
        $resultAdd = mysqli_query($conn, $sqlAdd);

        // $urlAdd = 'ad_news.php';
        // header('location: ' .$url);
    }
?>

    <style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    
                <?php
                    $sqlCateImg = 'SELECT * FROM categoryimage';
                    $resultCateImg = mysqli_query($conn, $sqlCateImg);
                    //$rowCateNews = mysqli_fetch_array($resultCateNews);

                    if (mysqli_num_rows($resultCateImg) > 0) {
                        //  hiển thị dữ liệu ra website

                ?>
                <div class="row">
                    <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <form class="form form-check" method="POST" enctype="multipart/form-data">

                                            <br/>
                                            
                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm bài viết</label>
                                            </div>


                                            <div class="row justify-content-center">
                                                <!-- form left -->
                                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" >
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                                        <label for="formGroupExampleInput" class="form-label">Danh mục bài viết</label>
                                                        <select name="id_categoryNews" class="form-select" aria-label="Default select example">
                                                            <option selected>Mở để chọn danh mục bài viết</option>
                                                            <?php

                                                                $sqlCateNews = 'SELECT * FROM categorynews';
                                                                $resultCateNews = mysqli_query($conn, $sqlCateNews);

                                                                //  lặp hết dữ liệu có trong db
                                                                if (mysqli_num_rows($resultCateNews) > 0) {
                                                                    //  hiển thị dữ liệu ra website
                                                                    while($row = mysqli_fetch_assoc($resultCateNews)) { 
                                                            ?>
                                                            
                                                            <option value="<?php echo $row['id_categoryNews'] ?>"> <?php echo $row['id_categoryNews'] . ' - ' . $row['name_categoryNews'] ?> </option>
                                                            <?php
                                                                    }
                                                                }
                                                                else {
                                                                    echo 'No data';
                                                                }

                                                            ?>
                                                        </select>
                                                    </div>
                                                    
                                                    <br>

                                                    <div class="mb-3">
                                                        <label for="formGroupExampleInput" class="form-label">Tiêu đề bài viết</label>
                                                        <textarea class="form-control" name="title_news" placeholder="Tiếu đề bài viết" id="floatingTextarea2" style="height: 75px"></textarea>
                                                    </div>

                                                    <br>

                                                    <div class="mb-3">
                                                        <label for="formGroupExampleInput" class="form-label">Mô tả bài viết</label>
                                                        <textarea class="form-control" name="description_news" placeholder="Mô tả bài viết" id="floatingTextarea2" style="height: 75px"></textarea>
                                                    </div>

                                                    <br>

                                                    <div class="mb-3">
                                                        <label for="formGroupExampleInput" class="form-label">URL ảnh bài viết</label>
                                                        <input type="text" name="urlImage_news" class="form-control" id="formGroupExampleInput" placeholder="URL ảnh bài viết" required>
                                                    </div>

                                                    <br>

                                                    <div class="mb-3">
                                                        <label for="formGroupExampleInput" class="form-label">Thời gian tạo bài</label>
                                                        <input type="date" name="dateCreate_post" class="form-control" id="formGroupExampleInput" placeholder="Thời gian tạo bài" required>
                                                    </div>

                                                    <br>

                                                    <div class="mb-3">
                                                        <label for="formGroupExampleInput" class="form-label">Số lượt xem bài viết</label>
                                                        <input type="number" name="numberOfReaders_news" class="form-control" id="formGroupExampleInput" placeholder="Số lượt xem bài viết" required>
                                                    </div>

                                                </div>

                                                <!-- form right -->
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="col-lg-9">
                                                            <label for="formGroupExampleInput" class="form-label">Nội dung bài viết</label>
                                                            <textarea class="form-control" name="content_news" placeholder="Nội dung bài viết" id="floatingTextarea2" style="height: 500px;"></textarea>
                                                        </div>
                                                        <div class="col-lg-3" >
                                                            <label for="formGroupExampleInput" class="form-label">Ghi chú:</label>
                                                            <p> Thêm ảnh: thẻ < img  src="link ảnh" alt="hiển thị khi ảnh bị lỗi"> </p>
                                                            <p> Xuống dòng: thẻ < br/> </p>

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <br>

                                            <button type="submit" name="submitAdd" class="btn btn-primary">Thêm tin tức</button>

                                            <br>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                    }
                    else {
                        echo '0 result';
                    }
                ?>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchNews" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchNews'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchNews']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>



    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <br>
            </div>
        </div>
    </div>

    <?php 
        // PHẦN XỬ LÝ PHP
        // BƯỚC 1: KẾT NỐI CSDL
        //có sắn rồi
 
        // BƯỚC 2: TÌM TỔNG SỐ RECORDS
        $result = mysqli_query($conn, 'SELECT COUNT(id_news) AS total FROM news');
        $row = mysqli_fetch_assoc($result);
        $total_records = $row['total'];
 
        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
        $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
        $limit = 5; // số dữ liệu tối đa của 1 page
 
        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang
        $total_page = ceil($total_records / $limit);
 
        // Giới hạn current_page trong khoảng 1 đến total_page
        if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
 
        // Tìm Start, vị trí bắt đầu page
        $start = ($current_page - 1) * $limit;
 
        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
        $result = mysqli_query($conn, "SELECT * FROM news LIMIT $start, $limit");
 
        ?>
        <div>
            <table class="table table-dark table-hover table-bordered" style="text-align: center;">
                <thead>
                    <tr>
                        <th scope="col">id_news</th>
                        <th scope="col">id_categoryNews</th>
                        <th scope="col">title_news</th>
                        <th scope="col">description_news</th>
                        <th scope="col">content_news</th>
                        <th scope="col">urlImage_news</th>
                        <th scope="col">image new</th>
                        <th scope="col">dateCreate_post</th>
                        <th scope="col">numberOfReaders_news</th>
                        <th scope="col">Sửa </th>
                        <th scope="col">Xóa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // PHẦN HIỂN THỊ TIN TỨC
                    // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                    while ($row = mysqli_fetch_assoc($result)){
                    ?>
            
                    <tr>
                        <th scope="row">
                            <?php echo $row['id_news']; ?>
                        </th>
                        <td>
                            <?php echo $row['id_categoryNews']; ?>
                        </td>
                        <td>
                            <?php echo $row['title_news']; ?>
                        </td>
                        <td>
                            <?php echo $row['description_news']; ?>
                        </td>
                        <td style="overflow: scroll; -webkit-line-clamp: 10; -webkit-box-orient: vertical; display: -webkit-box; width: 500px;">
                            <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0">
                                <?php echo $row['content_news']; ?>
                            </div>
                        </td>
                        <td>
                            <a href="<?php echo $row['urlImage_news']; ?>">
                                <?php echo $row['urlImage_news']; ?>
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo $row['urlImage_news']; ?>">
                                <img style="width: 100px; height 100px;" src="<?php echo $row['urlImage_news']; ?>">
                            </a>
                            </td>
                        <td>
                            <?php echo $row['dateCreate_post']; ?>
                        </td>
                        <td>
                            <?php echo $row['numberOfReaders_news']; ?>
                        </td>
                        <td>
                            <a style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_news_update.php?id_news=<?php echo $row['id_news']; ?>">Sửa</a>
                        </td>
                        <td>
                            <a onclick="return remove(<?php echo $row['id_news']; ?>)" style="background-color: red; padding: 5px 10px; color: black;" href="ad_news_remove.php?id_news=<?php echo $row['id_news']; ?>">Xóa</a>
                        </td>
                    </tr>
            
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>


        <div class="container">
        <div class="row justify-content-begin">
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                <nav aria-label="Page navigation example" style="left: 0; bottom: 0; margin: 20px; position: fixed; z-index: 100000;">
                    <p style="color: red; font-size: 20px;">
                        Mục trang
                    </p>
                    <ul class="pagination">
                        
           <?php 
            // PHẦN HIỂN THỊ PHÂN TRANG
            // BƯỚC 7: HIỂN THỊ PHÂN TRANG
 
            // nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
            if ($current_page > 1 && $total_page > 1){
                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="ad_news_paging.php?page='.($current_page - 1).'">Prev</a></li>';
            }
 
            // Lặp khoảng giữa
            for ($i = 1; $i <= $total_page; $i++){
                // Nếu là trang hiện tại thì hiển thị thẻ span
                // ngược lại hiển thị thẻ a
                if ($i == $current_page){
                    echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" style="color: red; border: 1px solid red;" href="ad_news_paging.php?page='.($current_page).'">'.$i.'</a></li> ';
                    
                }
                else{
                    echo ' <li class="page-item"><a class="page-link" href="ad_news_paging.php?page='.$i.'">'.$i.'</a></li>';
                }
            }
 
            // nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
            if ($current_page < $total_page && $total_page > 1){
                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="ad_news_paging.php?page='.($current_page + 1).'">Next</a></li> ';
            }
           ?>
                        <li class="page-item" style="margin: 0px 2px;">
                        
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    
    
    <script>
        function remove(id) {
            return confirm('Are you sure you want to delete the id = ' + id + ' element?')
        }
    </script>
