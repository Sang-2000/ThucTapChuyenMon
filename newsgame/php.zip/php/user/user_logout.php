<?php session_start(); 
 
    if (isset($_SESSION['email_user'])){
        unset($_SESSION['email_user']); // xóa session login
    }

    if(isset($_GET['id_news']) == true) {
        $id_news = $_GET['id_news'];

        // chuyển người dùng về trang trước khi đăng xuất
        $url = 'news_detail.php?id_news=' .$id_news;
        header('location: ' . $url);
    } else {
        // chuyển người dùng về home.php
        $url = '../user/user_login.php';
        header('location: ' . $url);
    }
?>