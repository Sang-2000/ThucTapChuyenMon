<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');
    //require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/user/get_userLogin.php');

    /// news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);

    // user database
    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news 
    WHERE id_categoryNews = 2
    GROUP BY dateCreate_post
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews);

?>


<!-- cotent gamers & streamers -->
<div class="container">
        <div class="row justify-content" style="width: 100%; height: auto; margin-bottom: 100px; margin-top: 50px;" style="background-color: lightseagreen;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 news_big" style="padding-right: 0px 10px; margin-bottom: 30px;">
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $rowNews['id_news']; ?>">
                            
                            <img src="<?php echo $rowNews['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h3><?php echo $rowNews['title_news']; ?></h3>
                        
                        </a>
                    </div>
                </div>         

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <p><?php echo $rowNews['description_news']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <h6 style="padding-left: 50%;"><?php echo $rowNews['dateCreate_post']; ?></h6>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                <?php
                     if (mysqli_num_rows($resultNews) > 0) {
                        while($row = mysqli_fetch_assoc($resultNews)) {
                ?>
                
                <div class="row">
                    <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12" style="text-align: justify;">
                         <!-- echo 'id: ' . $row['id_news']; ?> -->
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                            
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%; height: auto;"  alt="img" >
                            
                            <h5><?php echo $row['title_news']; ?></h5>
                        
                        </a>
                        <p style="float: right;"><?php echo $row['dateCreate_post']; ?></p>
                        <br/>
                        <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                    </div>
                    <div class="col-xl-10 col-lg-10 col-md-6 col-sm-12">
                    </div>
                </div>
                
                <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
        
                ?>
            </div>
            
           

            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12" style="padding: 4px; margin-top: 30px;">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                       <p style="background-color: darkcyan; border-left: 7px solid red; font-size: 25px; font-weight: 700; text-align: center;">
                            Game ngẫu nhiên
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <br/>
                        <?php 
                            $sqlGame = 'SELECT * FROM games';
                            $resultGame = mysqli_query($conn, $sqlGame);

                            //echo mysqli_num_rows($resultGame) . '<br/>';
                            
                            $random = rand(1, mysqli_num_rows($resultGame)); // lấy ra id
                            //echo $random . '<br/>';

                            $sqlRandomGame = "SELECT * FROM games WHERE id_game = '$random'";
                            $resultRandomGame = mysqli_query($conn, $sqlRandomGame);
                            $rowRandomGame = mysqli_fetch_array($resultRandomGame);
                        ?>

                        <a class="news_post nav-link" href="detail_game.php?id_news=<?php echo $rowRandomGame['id_game']; ?>">
                            <img src="<?php echo $rowRandomGame['urlImage_game']; ?>" style="width: 100%; height: auto;" alt="error">
                            <b>
                                <p style="text-align: center; font-size: 20px;"> <?php echo $rowRandomGame['name_game'] ?></p>
                            </b>
                        </a>
                        <div>
                            <b>
                                <p>Thể loại: <?php echo $rowRandomGame['category_game']; ?></p>
                                <p>Đồ họa: <?php echo $rowRandomGame['graphics_game']; ?></p>
                            </b>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 "> 
                <h1>Tin khác</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
        </div>


        <div class="row" style="margin-top: 50px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 "> 
                <?php
                    $sql = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
                    FROM news 
                    WHERE id_categoryNews = 2
                    GROUP BY dateCreate_post, id_news, description_news
                    ORDER BY days_difference ASC
                    LIMIT 4, 10';

                    $query = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($resultNews) > 0) {
                                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($query)) {
                ?>

                <div class="row" style="margin-bottom: 20px; height: 200px;">
                    <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                            
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%;"  alt="img">
                                            
                        </a>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 " style="text-align: justify;">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                           
                            <h5><?php echo $row['title_news']; ?></h5>
                                  
                        </a>

                        <p style="float: right; font-size: 15px;">
                            <i>
                            <?php echo $row['dateCreate_post']; ?>
                            </i>
                        </p>
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 ">

                    </div>
                </div>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">

                <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
            
                ?>
            </div>

            <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 " >
            </div>

            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 " >
                <?php 
                    $sqlImg = 'SELECT * FROM image';
                    $resultImg = mysqli_query($conn, $sqlImg);

                    //echo mysqli_num_rows($resultGame) . '<br/>';
                            
                    $randomImg = rand(1, mysqli_num_rows($resultImg)); // lấy ra id
                    //echo $randomImg . '<br/>';

                    $sqlRandomImg = "SELECT * FROM image WHERE id_image = '$randomImg'";
                    $resultRandomImg= mysqli_query($conn, $sqlRandomImg);
                    $rowRandomImg = mysqli_fetch_array($resultRandomImg);
                ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <p style="font-size: 25px; border-left: 7px solid red; text-align: center; background-color: darkcyan">Ảnh</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                <img src="<?php echo $rowRandomImg['url_image'] ?>" style="width: 100%; max-height: 250px;" alt="img eror">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
