<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    // lấy ra bài viết mới nhất. Có 2 cách:
        //  Cách 1 dùng truy vấn sql sắp xếp
        // Cách 2: lấy ra bài viết cuối cùng của database


    // news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);

    // user database
    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news 
    WHERE id_categoryNews = 4
    GROUP BY dateCreate_post
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews);
    //echo $rowNews['id_news'] . ' - ' . $rowNews['dateCreate_post'];
?>

    <div class="container">
        <div class="row justify-content" style="width: 100%; height: auto; margin-bottom: 100px; margin-top: 50px;">
            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 news_big" style="padding-right: 0px 10px; margin-bottom: 30px;">
                <?php //echo $rowNews['id_news'] . ' - ' . $rowNews['dateCreate_post']; ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $rowNews['id_news']; ?>">
                            
                            <img src="<?php echo $rowNews['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h3><?php echo $rowNews['title_news']; ?></h3>
                        
                        </a>
                    </div>
                </div>         

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <p><?php echo $rowNews['description_news']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <h6 style="float: right;"><?php echo $rowNews['dateCreate_post']; ?></h6>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12" style="height: auto; margin: 0px 50px 30px 40px;">
                
                <?php
                     if (mysqli_num_rows($resultNews) > 0) {
                                     
                        //  số dữ liệu của bảng ... có trong db
                        //echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($resultNews) . '<br />';
                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($resultNews)) {
                ?>
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                            
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h5><?php echo $row['title_news']; ?></h5>
                        
                        </a>
                        <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                    </div>
                    <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12">
                    </div>
                </div>

                <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
        
                ?>

            </div>

            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                       <p style="background-color: darkcyan; border-left: 7px solid red; font-size: 25px; font-weight: 700; text-align: center;">
                            Game ngẫu nhiên
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <br/>
                        <?php 
                            $sqlGame = 'SELECT * FROM games';
                            $resultGame = mysqli_query($conn, $sqlGame);

                            //echo mysqli_num_rows($resultGame) . '<br/>';
                            
                            $random = rand(1, mysqli_num_rows($resultGame)); // lấy ra id
                            //echo $random . '<br/>';

                            $sqlRandomGame = "SELECT * FROM games WHERE id_game = '$random'";
                            $resultRandomGame = mysqli_query($conn, $sqlRandomGame);
                            $rowRandomGame = mysqli_fetch_array($resultRandomGame);
                        ?>

                        <a class="news_post nav-link" href="detail_game.php?id_news=<?php echo $rowRandomGame['id_game']; ?>">
                            <img src="<?php echo $rowRandomGame['urlImage_game']; ?>" style="width: 100%; height: auto;" alt="error">
                            <b>
                                <p style="text-align: center; font-size: 20px;"> <?php echo $rowRandomGame['name_game'] ?></p>
                            </b>
                        </a>
                        <div>
                            <b>
                                <p>Thể loại: <?php echo $rowRandomGame['category_game']; ?></p>
                                <p>Đồ họa: <?php echo $rowRandomGame['graphics_game']; ?></p>
                            </b>
                            <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
            

    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 ">
                <p style="text-shadow: 5px 5px 5px black; font-size: 30px;">BÀI VIẾT KHÁC</p>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                <!-- bắt đầu php -->
                

                <div class="row">
                    <!-- thử bắt đầu php từ đây xem có ngang đc k -->
                    <?php
                    $sql = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
                    FROM news 
                    WHERE id_categoryNews = 4
                    GROUP BY dateCreate_post, id_news, title_news, description_news
                    ORDER BY days_difference ASC
                    LIMIT 4, 16';

                    $query = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($resultNews) > 0) {
                                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($query)) {
                    ?>

                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12" style="text-align: justify; color: black;">
                            
                        <div class="row">
                            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12" style="text-align: justify;">
                                <?php //echo 'id: ' . $row['id_news']; ?>
                                <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                        
                                    <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%; height: auto; text-align: center;"  alt="img" >
                                                        
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <a href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                    <br>
                                        <h6><?php echo $row['title_news']; ?></h6>
                                    </br>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="font-size: 15px; text-align: right;">
                                <h6><?php echo $row['dateCreate_post']; ?></h6>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="font-size: 15px;">
                                 <p><?php //echo $row['description_news']; ?></p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="font-size: 15px;">
                                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                            </div>
                        </div>

                    </div>

                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12">
                    </div>

                    <!-- kết thúc php thử ở đây -->
                        <?php
                            }
                        }
                        else {
                            echo '0 result';
                        }
                    
                        ?>
                </div>

                <!-- đóng php -->
            </div>
        </div>
    </div>
