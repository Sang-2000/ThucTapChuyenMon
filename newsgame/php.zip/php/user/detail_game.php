<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');
    //require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/user/get_userLogin.php');
    

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news
    GROUP BY dateCreate_post, id_news
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews); // lấy data đầu tiên của câu truy vấn SQL
    // Khi lặp sẽ bỏ qua data này và lấy từ data kế tiếp

    //echo '<br/><br/>id_categoryNews' . $rowNews['id_categoryNews'];


    // news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Games</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <style>
        
        a:hover{
            color: red;
        }

        img:hover {
            opacity: 0.5;
        }

    </style>

</head>
<body style="font-family: Helvetica, Arial, sans-serif;">

  <div div class="container">
        <div class="row" style="left: 0; top: 0; right: 0; position: fixed; z-index: 100000; width: 100%;">
            <!-- menu user -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="row">
                </div>
                <nav class="navbar navbar-expand-md bg-dark navbar-dark" style="text-align: center;">
                    
                    <a class="nav-link" href="home.php" >
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                            <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                        </svg>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <?php 
                                if (mysqli_num_rows($resultCateNews) > 0) {
                                    //  hiển thị dữ liệu ra website
                                    while($rowCateNews = mysqli_fetch_assoc($resultCateNews)) { 
                            ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?p=<?php echo $rowCateNews['link_categoryNews'] ?>"> <?php echo $rowCateNews['name_categoryNews'] ?></a>
                            </li>
                            <?php
                                    }
                                }
                                else {
                                    echo '0 result';
                                }
                            ?>
                        </ul>
                    </div>
                    <div>
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-lg-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Key word</label>
                                <input type="text" name="searchField" class="form-control" id="inputPassword2" placeholder="Key word" required>
                            </div>
                            <button type="submit" name="searchBtn" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <!-- header -->
    <div class="container">

        <div class="row" style="text-align: center; background-color: lightseagreen; margin-top: 100px;">
            <!-- logo -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
                <a href="">
                    <img style="width:100%; height: 70px;" src="https://gameviet.mobi/wp-content/uploads/2020/02/download-hinh-nen-lien-quan-mobile-gameviet.mobi_-1280x640.jpg" alt="logo">
                </a>
            </div>
            <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
            <br/><br/>
                <h1>Game world news site</h1>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12">
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            </div>
        </div>
    </div>


    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <?php

                if(isset($_GET['id_game'])){
                    $id_game = $_GET['id_game'];
                }
                else {
                    $id_game = 2;
                }
                $sqlGame = "SELECT * FROM games WHERE id_game = '$id_game'";
                $resutlGame = mysqli_query($conn, $sqlGame);
                $rowGame = mysqli_fetch_array($resutlGame);

            ?>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12">
                <div class="row " style="height: 300px;;">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <img src="<?php echo $rowGame['urlImage_game']; ?>"style="width: 100%; height: 250px; box-shadow: 5px 5px 5px silver;" alt="img game">
                        <p style="font-size: 20px; font-weight: 700; text-align: center;"><?php echo $rowGame['name_game']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <p><?php echo 'Thể loại: ' . $rowGame['category_game']; ?></p>
                                <p><?php echo 'Đồ họa: ' . $rowGame['graphics_game']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6 col-lg-6 col-md-8 col-sm-12" style="text-align: justify;">
                <p><?php echo $rowGame['overview_game']; ?></p>
            </div>
        </div>
    </div>


    <!-- game -->
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
                <p style="font-size: 25px;">GAME KHÁC</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
        </div>
    </div>

    <!-- hiển thị dữ liệu game -->
    <div class="container">
            <div class="row" style="margin-top: 100px;">
                <?php 
                    // PHẦN XỬ LÝ PHP
                    // BƯỚC 1: KẾT NỐI CSDL
                    //có sắn rồi
            
                    // BƯỚC 2: TÌM TỔNG SỐ RECORDS
                    $result = mysqli_query($conn, 'SELECT COUNT(id_game) AS total FROM games');
                    $row = mysqli_fetch_assoc($result);
                    $total_records = $row['total'];
            
                    // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
                    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                    $limit = 4;
            
                    // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
                    // tổng số trang
                    $total_page = ceil($total_records / $limit);
            
                    // Giới hạn current_page trong khoảng 1 đến total_page
                    if ($current_page > $total_page){
                        $current_page = $total_page;
                    }
                    else if ($current_page < 1){
                        $current_page = 1;
                    }
            
                    // Tìm Start
                    $start = ($current_page - 1) * $limit;
            
                    // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
                    // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                    $result = mysqli_query($conn, "SELECT * FROM games LIMIT $start, $limit");
            
                ?>

                <?php 
                    // PHẦN HIỂN THỊ TIN TỨC
                    // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                    while ($row = mysqli_fetch_assoc($result)){
                ?>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6" style="width: 90%;">
                            <div class="row">
                                <a href="detail_game.php?id_news=<?php echo $row['id_game']; ?>">
                                    <img src="<?php echo $row['urlImage_game']; ?>" alt="img news" style="height: 200px; width: 90%;">
                                    <p style="height: 70px; width: 90%; text-align: center; font-size: 25px;"><?php echo $row['name_game']; ?></p>
                                </a>
                            </div>
                            <div class="row">
                                <p>
                                    Thể loại: <?php echo $row['category_game']; ?>
                                </p>
                            </div>
                            <div class="row">
                                <p>
                                    Đồ họa: <?php echo $row['graphics_game']; ?>
                                </p>
                                
                            </div>
                        </div>
                <?php
                    }
                ?>
            </div>

            <div class="row justify-content-end" style="text-align: right;">
                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12" style="margin: 50px;">
                    <nav aria-label="Page navigation example">
                        
                        <ul class="pagination" >
                            <?php 
                                // PHẦN HIỂN THỊ PHÂN TRANG
                                // BƯỚC 7: HIỂN THỊ PHÂN TRANG
                    
                                // nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
                                if ($current_page > 1 && $total_page > 1){
                                    echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="detail_game.php?page='.($current_page - 1).'">Prev</a></li>';
                                }
                    
                                // Lặp khoảng giữa
                                for ($i = 1; $i <= $total_page; $i++){
                                    // Nếu là trang hiện tại thì hiển thị thẻ span
                                    // ngược lại hiển thị thẻ a
                                    if ($i == $current_page){
                                        echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" style="color: red; border: 1px solid red;" href="detail_game.php?page='.($current_page).'">'.$i.'</a></li> ';
                                    }
                                    else{
                                        echo ' <li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="detail_game.php?page='.$i.'">'.$i.'</a></li>';
                                    }
                                }
                    
                                // nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
                                if ($current_page < $total_page && $total_page > 1){
                                    echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="detail_game.php?page='.($current_page + 1).'">Next</a></li> ';
                                }
                            ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>


    <!-- news -->
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                <p style="font-size: 25px;">TIN KHÁC</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
        </div>
    </div>

    <!-- hiển thị dữ liệu news -->
    <div class="container">
        <div class="row">
            <?php
                $sqlNews = "SELECT * FROM news LIMIT 4";
                $resultNews = mysqli_query($conn, $sqlNews);

                if(mysqli_num_rows($resultNews) > 0) {
                    while($row = mysqli_fetch_assoc($resultNews)){
            ?>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="row" style="height: 500px; margin-top: 50px;">
                    
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <div class="row " style="height: 300px;;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                <div class="row ">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 " style="height: 450px;">
                                        <a href="news_detail.php?id_game=<?php echo $row['id_news']; ?>">
                                            <img src="<?php echo $row['urlImage_news']; ?>"style="width: 100%; height: 250px;" alt="img game">
                                            <p style="font-size: 20px; font-weight: 700; text-align: center;"><?php echo $row['title_news']; ?></p>
                                        </a>
                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                        <p style="float: right; padding-bottom: 10px;"><?php echo $row['dateCreate_post']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <?php
                    }
                }
                else {
                    
                }
            ?>
        </div>
    </div>


    <!-- banner end -->
    <div class="container">
        <div class="row" style="margin: 5% 0px">
            <div class="col-lg-12">
                <img style="width: 100%; height: 200px;" src="https://image.freepik.com/free-vector/digital-neon-game-banner_1017-19897.jpg" alt="end game">
            </div>
        </div>
    </div>
   
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h3>About Us</h3>
                <p>We bring the most accurate and fastest news possible to you</p>
                <p>Hope what we do can help you in some way.</p>
                <p>Thank you for coming to us</p>
            </div>
            <div class="col-sm-4">
                <h3>Tutorial</h3>
                <p><a href="">Home</a></p>
                <p><a href="">Image game</a></p>
                <p><a href="">News</a></p>
                <p><a href="">Category game</a></p>
            </div>
            <div class="col-sm-4">
                <h3>Contact</h3>
                <p>Email: dovansang2536@gmail.com</p>
                <p>Phone Number: 1234567890</p>
                <p>Group Facebook: news game (null)</p>
            </div>
        </div>
    </div>
</body>
</html>