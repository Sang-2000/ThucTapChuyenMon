<?php
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');
 
    // Nếu không phải là sự kiện đăng ký thì không xử lý
    // 
    //     die('');
    // }
    
          
    //Khai báo utf-8 để hiển thị được tiếng việt

    if (isset($_POST['submitRegester'])){
        header('Content-Type: text/html; charset=UTF-8');
            
        //Lấy dữ liệu nhạp vào của người dfng
        $name_user  = addslashes($_POST['name_user']);
        $email_user = addslashes($_POST['email_user']);
        $password   = addslashes($_POST['password']);
        $rePassword = addslashes($_POST['rePassword']);
            
        //Kiểm tra người dùng đã nhập liệu đầy đủ chưa
        if (!$email_user || !$name_user || !$password || !$rePassword)
        {
            echo "Vui lòng nhập đầy đủ thông tin. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }
            
        
        //Kiểm tra email có đúng định dạng hay không
        if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+\.[A-Za-z]{2,6}$/", $email_user))
        {
            echo "Email này không hợp lệ. Vui long nhập email khác. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }


        //Kiểm tra email đã có người dùng chưa
        if (mysqli_num_rows(mysqli_query($conn, "SELECT email_user FROM user WHERE email_user = '$email_user'")) > 0)
        {
            echo "Email dăng nhập này đã có người dùng. Vui lòng chọn Email khác hoặc kiểm tra lại email. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }

        
        //Kiểm tra E-mail có tồn tại không
        $secure_check = filter_var($to_email, FILTER_VALIDATE_EMAIL);
            if ($secure_check == false) {
            echo "<script>alert('E-mail không tồn tại. Vui lòng kiểm tra lại!');</script>";
        }


        //Kiểm tra tên đăng nhập này đã có người dùng chưa
        if (mysqli_num_rows(mysqli_query($conn, "SELECT name_user FROM user WHERE name_user = '$name_user'")) > 0){
            echo "Tên hiển thị này đã có người dùng. Vui lòng chọn tên đăng nhập khác. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }


        //Kiểm tra mật khẩu có kí tự đặc biệt hay không
        if (!preg_match("/^([A-Z]){1}([\w_\.!@#$%^&*()]+){6,10}$/", $password))
        {
            echo "Mật khẩu phải lớn hơn 6 kí tự, nhỏ hơn 10 kí tự và không chứa kí tự đặc biệt. Vui lòng nhập lại password. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }
            
        //Kiểm tra mật khẩu đăng nhập có số ký tự phù hợp không
        if (strlen($password) > 10 || strlen($password) < 6)
        {
            echo "Mật khẩu phải nhỏ hơn 10 kí tự và lớn hơn 6 kí tự. Vui lòng nhập lại. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }


        //Kiểm tra mật khẩu nhập lại có trùng khớp không
        if ($password != $rePassword)
        {
            echo "Mật khẩu nhập lại không khớp. Vui lòng kiểm tra lại. <a href='javascript: history.go(-1)'>Trở lại</a>";
            exit;
        }
        // else{
        //     Mã khóa mật khẩu
        //     $password = md5($password);
        // }


        //Lưu thông tin thành viên vào database
        $resultAdduser = mysqli_query($conn, "INSERT INTO user (id_user, name_user , email_user, password, Position_user, isBlock_user) 
        VALUE ('', '$user_name', '$email_user', '$password', 'unlock', 'user')");
                            
        //Thông báo quá trình lưu
        if ($resultAdduser > 0)
            echo "Quá trình đăng ký thành công. <a href='?p=home.php'>Về trang chủ</a>";
        else
            echo "Có lỗi xảy ra trong quá trình đăng ký. <a href='user_registration.php'>Thử lại</a>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
+
</head>
<body style="background-image: url('https://www.vgr.com/wp-content/uploads/2021/05/Gaming-News.jpg'); background-repeat: no-repeat, repeat; background-size: cover;">
<div class="container" style="margin-top: 50px;">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 " style="padding: 4px; ">
            </div>

            <div class="col-xl-6 col-lg-6 col-md-9 col-sm-12" style="border-radius: 10px; border: 3px solid #ff0000; color: red;">
            <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="text-align: center;">
                        <a style="padding: 5px 10px; color: white; float: right;" href="../user/user_login.php">Quay lại trang chủ</a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="text-align: center;">
                        <p style="font-weight: 700; font-size: 30px;">ĐĂNG KÝ</p>
                    </div>
                </div>
                <form class="form" method="POST" enctype="multipart/form-data">

                    <!-- User id indentity-->
                    <br/>

                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label" style="font-weight: 600; font-size: 20px;">Nhập tên</label>
                        <input type="text" name="name_user" class="form-control" id="formGroupExampleInput" placeholder="Enter user email" required>
                    </div>

                    <br/>

                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label" style="font-weight: 600; font-size: 20px;">Email</label>
                        <input type="text" name="email_user" class="form-control" id="formGroupExampleInput" placeholder="Enter user email" required>
                    </div>

                    <br/>

                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label" style="font-weight: 600; font-size: 20px;">Mật khẩu</label>
                        <input type="password" name="password" class="form-control" id="formGroupExampleInput" placeholder="Enter user pasword" required>
                    </div>

                    <br/>

                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label" style="font-weight: 600; font-size: 20px;">Nhập lại mật khẩu</label>
                        <input type="password" name="rePassword" class="form-control" id="formGroupExampleInput" placeholder="Enter user pasword" required>
                    </div>

                    <br/>

                    <div class="mb-3">
                        <button type="submit" name="submitRegester" class="btn btn-primary">Đâng ký</button>
                        <a style="padding: 5px 10px; color: white; float: right;" href="../user/user_login.php">Quay lại đăng nhập</a>
                    </div>

                    <br>

                    <br>

                    </form>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 " style=" padding: 4px; ">
            </div>
            
        </div>
</body>
</html>