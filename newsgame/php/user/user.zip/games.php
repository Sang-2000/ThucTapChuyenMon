<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');
    //require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/user/get_userLogin.php');
    

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news
    GROUP BY dateCreate_post, id_news
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews); // lấy data đầu tiên của câu truy vấn SQL
    // Khi lặp sẽ bỏ qua data này và lấy từ data kế tiếp

    //echo '<br/><br/>id_categoryNews' . $rowNews['id_categoryNews'];


    // news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);


    // user database
    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);
    
?>


    <div class="container">
        <div class="row">
            <?php
                $sqlGame = "SELECT * FROM games";
                $resultGame = mysqli_query($conn, $sqlGame);

                if(mysqli_num_rows($resultGame) > 0) {
                    while($row = mysqli_fetch_assoc($resultGame)){
            ?>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="row" style="height: 400px; margin-top: 50px;">
                    
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <div class="row " style="height: 300px;;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 game">
                                <a href="detail_game.php?id_game=<?php echo $row['id_game']; ?>">
                                    <img src="<?php echo $row['urlImage_game']; ?>"style="width: 100%; height: 250px;" alt="img game">
                                    <p style="font-size: 20px; font-weight: 700; text-align: center;"><?php echo $row['name_game']; ?></p>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <p><?php echo 'Thể loại: ' . $row['category_game']; ?></p>
                                        <p><?php echo 'Đồ họa: ' . $row['graphics_game']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                    }
                }
                else {
                    
                }
            ?>
        </div>
    </div>
