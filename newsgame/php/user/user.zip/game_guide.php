<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    // news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);

    // user database
    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news 
    WHERE id_categoryNews = 3
    GROUP BY dateCreate_post
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews);
    //echo $rowNews['id_news'] . ' - ' . $rowNews['dateCreate_post'];


?>


<!-- content games -->
    <div class="container">
        <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 "> 
                <h1>TIN MỚI</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>

        <div class="row justify-content" style="width: 100%; height: auto; margin-bottom: 100px; margin-top: 50px;">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 news_big" style="padding-right: 0px 10px; margin-bottom: 30px;">
                <?php echo $rowNews['id_news'] . ' - ' . $rowNews['dateCreate_post']; ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $rowNews['id_news']; ?>">
                            
                            <img src="<?php echo $rowNews['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h3><?php echo $rowNews['title_news']; ?></h3>
                        
                        </a>
                    </div>
                </div>         

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <p><?php echo $rowNews['description_news']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <h6 style="float: right;"><?php echo $rowNews['dateCreate_post']; ?></h6>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12" style="height: 500px; margin: 0px 50px 30px 40px;">
                
                <?php
                     if (mysqli_num_rows($resultNews) > 0) {
                                     
                        //  số dữ liệu của bảng ... có trong db
                        echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($resultNews) . '<br />';
                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($resultNews)) {
                ?>
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                            
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h5><?php echo $row['title_news']; ?></h5>
                        
                        </a>

                        <h6 style="float: right;"><?php echo $rowNews['dateCreate_post']; ?></h6>
                        <br/>
                        <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">

                    </div>
                </div>

                <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
        
                ?>

            </div>

            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-0" style="padding: 4px; margin-top: 30px;">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 " style="background-color: darkcyan;">
                        <img src="https://i.pinimg.com/236x/07/7a/54/077a54159b227581fb4b379664079a75--banner.jpg" alt="img banner" style="width: 100%; Height: auto;">
                        <img src="https://i.pinimg.com/236x/ba/03/63/ba03633c23647498bb083a43ddf14ab6.jpg" alt="img banner" style="width: 100%; Height: auto;">
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 " style="background-color: darkcyan;">
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 "> 
                <h1>TIN KHÁC</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            <div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 "> 
            </div>
        </div>

        <div class="row" style="margin-top: 50px;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                <!-- bắt đầu php -->
                
                <div class="row">
                    <!-- thử bắt đầu php từ đây xem có ngang đc k -->
                    <?php
                    $sql = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
                    FROM news 
                    WHERE id_categoryNews = 3
                    GROUP BY dateCreate_post, id_news, title_news, description_news
                    ORDER BY days_difference ASC
                    LIMIT 4, 12';;

                    $query = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($resultNews) > 0) {
                                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($query)) {
                    ?>

                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12" style="height: 400px; text-align: justify; color: black;">
                            
                        <div class="row" style="height: 200px;">
                            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12" style="text-align: justify;">
                                <?php echo 'id: ' . $row['id_news']; ?>
                                <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                        
                                    <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%; height: 200px; object-fit: contain;"  alt="img" >
                                                        
                                </a>

                                
                            </div>
                        </div>

                        <div class="row" style="height: 150px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <a href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                    <br>
                                        <p style="color: black; margin-top: 30px;"><?php echo $row['title_news']; ?></p>
                                    </br>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="font-size: 15px; text-align: right;">
                                <p style="font-size: 14px;">
                                    <i>
                                        <?php echo $row['dateCreate_post']; ?>
                                    </i>
                                </p>
                            </div>
                        </div>

                        <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">



                    </div>
                    <!-- kết thúc php thử ở đây -->
                        <?php
                            }
                        }
                        else {
                            echo '0 result';
                        }
                    
                        ?>
                </div>
            </div>
        </div>
    </div>
            
