<?php 
    session_start();
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');


    // giờ hiện tài
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $date_comment = date('d/m/Y - H:i:s'); 
    echo 'Now: ' . $date_comment;


    // category news tạo menu động
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);


    // kiểm tra id_new có tồn tại không
    if(isset($_GET['id_news'])){
        $id_news = $_GET['id_news'];

        // tăng số lượt xem bài viết lên 1
        // Nhược điểm: sẽ tăng ngay cả khi tab lại
        $sqlView = "UPDATE news SET numberOfReaders_news = numberOfReaders_news + 1 WHERE id_news = '$id_news'";
        $resultView = mysqli_query($conn, $sqlView);
    } else {
        $id_news = 5;// gán cứng bài viết sau khi đăng nhập
    }


    // news database lấy ra id bài viết
    $sqlNews = "SELECT * FROM news WHERE id_news = '$id_news'";
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_array($resultNews);
    $view = $rowNews['numberOfReaders_news']; // tăng số lượt xem thêm 1
    //echo 'View = ' .$view + 1;


    // kiểm tra người dùng đăng nhập hay không
    if(isset($_SESSION['email_user'])){
        $email_user = $_SESSION['email_user'];
    }
    else {
        $email_user = "";
    }


    // user nhấn vào nút 'bình luận'
    if(isset($_POST['submitComment'])){
        $content_comment = $_POST['content_comment'];
        $date_comment = date('y-m-d'. ' ' .'h:i:s');

        // lưu bình luận user vào commentposts
        if($content_comment == ""){echo 'Bạn chưa viết bình luận.';}
        else {
            // truy vấn đến user để lấy id của email
            $sqlId = "SELECT * FROM user WHERE email_user = '$email_user'";
            $resultId = mysqli_query($conn, $sqlId);
            $rowId = mysqli_fetch_array($resultId);
            $id_userEmail = $rowId['id_user'];
            //echo "<script> alert('id_user: $id_userEmail - id_news: $id_news - content_comment: $content_comment - date: $date_comment'); </script>";

            //truy vấn đển commentposts để thêm dữ liệu
            $sql = "INSERT INTO commentposts(id_news, id_user, content_comment, date_comment) 
            VALUES('$id_news', '$id_userEmail', '$content_comment', '$date_comment')";
            $result = mysqli_query($conn, $sql);
        }

        $url = 'news_detail.php?id_new=' .$id_news;
        header('location: ' .$url);
        
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Detail</title>

    <<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <style>
        a:hover{
            color: red;
        }

        img:hover {
            opacity: 0.5;
        }
    </style>

</head>
<body style="font-family: Helvetica, Arial, Tahoma, sans-serif;">

    <div class="container">
        <div class="row" style="left: 0; top: 0; position: fixed; z-index: 100000; width: 100%; background-color: #333333;">
            <!-- menu user -->
            <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12">
                
                <nav class="navbar navbar-expand-md bg-dark navbar-dark" style="text-align: center; border-right: 3px solid red;">
                    
                    <a class="nav-link" href="../user/index.php?p=home.php">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                            <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                        </svg>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar" >
                        <ul class="navbar-nav">
                            <?php 
                                if (mysqli_num_rows($resultCateNews) > 0) {
                                    //  hiển thị dữ liệu ra website
                                    while($rowCateNews = mysqli_fetch_assoc($resultCateNews)) { 
                            ?>
                            <li class="nav-item" style="border-left: 1px solid red;">
                                <a class="nav-link <?php $rowCateNews['link_categoryNews']; ?>" href="index.php?p=<?php echo $rowCateNews['link_categoryNews']; ?>"> <?php echo $rowCateNews['name_categoryNews']; ?></a>
                            </li>
                            
                            <?php
                                    }
                                }
                                else {
                                    echo '0 result';
                                }
                            ?>
                        </ul>
                    </div>
                    <div>
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-lg-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="text" name="searchField" class="form-control" id="inputPassword2" placeholder="Key word" required>
                            </div>
                            <button type="submit" name="searchBtn" class="btn btn-primary mb-2" style="float: right;">Tìm kiếm</button>
                        </form>
                    </div>
                </nav>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-12 col-sm-12" style="text-align: center;">
                          <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <br/>
                        
                        <?php 
                            if ($email_user != "") {
                        ?>
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown">
                                <?php echo $email_user ?>
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuLink">
                                <li><a class="dropdown-item" href="user_login.php?id_news=<?php echo $id_news ?>">Đăng nhập</a></li>
                                <li><a class="dropdown-item" href="user_registration.php">Đăng ký</a></li>
                                <li><a class="dropdown-item" href="user_logout.php?id_news=<?php echo $id_news ?>">Đăng xuất</a></li>
                            </ul>
                        </div>
                        <?php
                            }
                            else {
                        ?>
                        
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown">
                                Tài khoản
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuLink">
                                <li><a class="dropdown-item" href="user_login.php?id_news=<?php echo $id_news ?>">Đăng nhập</a></li>
                                <li><a class="dropdown-item" href="user_registration.php">Đăng ký</a></li>
                            </ul>
                        </div>
                        <?php
                            }
                        ?>
                    </div>
                </div>      
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-10">
                
            </div>
        </div>
    </div>

    
<?php echo $email_user; ?>


    <!-- header -->
    <div class="container">

        <div class="row" style="text-align: center; background-color: lightseagreen; margin-top: 100px;">
            <!-- logo -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
                <a href="">
                    <img style="width:100%; height: 100px;" src="https://gameviet.mobi/wp-content/uploads/2020/02/download-hinh-nen-lien-quan-mobile-gameviet.mobi_-1280x640.jpg" alt="logo">
                </a>
            </div>
            <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
            <br/><br/>
                <p style="text-shadow: 5px 5px 5px silver; font-size: 50px; font-family:'Courier New', Courier, monospace; font-style: italic;">Game world news site</p>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                <!-- bên phải logo và chữ -->
            </div>
        </div>

        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12">
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            </div>
        </div>
    </div>

    

    <!-- search khi có key word, bình thường sẽ ẩn-->
    <!-- // sự kiện khi nhấn button search -->
    <?php
        if(isset($_POST['searchBtn'])){
            $searchField = $_POST['searchField'];
        
            // kiểm tra xem có dữ liệu nhập vào không
            if($searchField != ''){
                //echo 'key word:  ' . $searchField;
                
                $sqlSearch = "SELECT * 
                FROM news 
                WHERE title_news LIKE '%" . $_POST['searchField'] ."%' OR description_news LIKE '%" . $_POST['searchField'] ."%' 
                LIMIT 0, 25";
                $resultSearch = mysqli_query($conn, $sqlSearch);
                
                // $url = 'search.php?searchField=' .$searchField;
                // header('location: ' .$url);
    ?>
    <div class="container" style="background-color: silver; margin-top: 50px; box-shadow: 5px 10px 5px #888888;">
        <div class="row">
            <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 ">
                <h1>KẾT QUẢ TÌM KIẾM</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 ">
            </div>
        </div>

        <div class="row">
            <?php

                    if (mysqli_num_rows($resultSearch) > 0) {
                                        
                        //  số dữ liệu của bảng ... có trong db
                        //echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($resultNews) . '<br /><br />';
                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($resultSearch)) {
            ?>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <div class="row" style="height: auto; border-left: 2px solid red;">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12" style="height: fit-content">
                        <a href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%; height: 100px;"  alt="img" >
                        </a>
                    </div>

                    <div class="col-xl-8 col-lg-8 col-md-6 col-sm-12" style="height:fit-content;">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                <a href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                    <h3><?php echo $row['title_news']; ?></h3>
                                </a>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                <p style="float: right;">
                                    <i>
                                        <?php echo $row['dateCreate_post']; ?>
                                    </i>
                                </p>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                <p style="font-size: 15px;">
                                    <i>
                                    <?php echo $row['description_news']; ?> 
                                    </i>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
            </div>
            <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
            ?>
        </div>
    </div>
    <?php
            }
            else {
                echo 'Vui lòng nhập vào "Key word"';
            }
        }
    ?>


<!-- // content detail post -->
    <div class="container">
        <div class="row">

        <?php
            // news database
            // $sqlNews = "SELECT * FROM news WHERE id_news = $id_news";
        
            // $resultNews = mysqli_query($conn, $sqlNews);
            // $rowNews = mysqli_fetch_array($resultNews);
        ?>

            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12">

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <h1>
                            <b>
                                <?php
                                    echo $rowNews['title_news'] . '<br/>';
                                ?>
                            </b>
                        </h1>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-0">
                     
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12">
                        <?php
                            echo $rowNews['dateCreate_post'] . '<br/><br/>';
                        ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <?php
                            echo $rowNews['description_news'];
                        ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="text-align: justify;">
                        <?php
                            echo $rowNews['content_news'];
                        ?>
                    </div>
                </div>
            </div>

            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1">
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-1" style=" padding: 4px;">
               
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                       <p style="background-color: darkcyan; border-left: 7px solid red; font-size: 25px; font-weight: 700; text-align: center;">
                            Game ngẫu nhiên
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <br/>
                        <?php 
                            $sqlGame = 'SELECT * FROM games';
                            $resultGame = mysqli_query($conn, $sqlGame);

                            //echo mysqli_num_rows($resultGame) . '<br/>';
                            
                            $random = rand(1, mysqli_num_rows($resultGame)); // lấy ra id
                            //echo $random . '<br/>';

                            $sqlRandomGame = "SELECT * FROM games WHERE id_game = '$random'";
                            $resultRandomGame = mysqli_query($conn, $sqlRandomGame);
                            $rowRandomGame = mysqli_fetch_array($resultRandomGame);
                        ?>

                        <a class="news_post nav-link" href="detail_game.php?id_game=<?php echo $rowRandomGame['id_game']; ?>">
                            <img src="<?php echo $rowRandomGame['urlImage_game']; ?>" style="width: 100%; height: auto;" alt="error">
                            <b>
                                <p style="text-align: center; font-size: 20px;"> <?php echo $rowRandomGame['name_game'] ?></p>
                            </b>
                        </a>
                        <div>
                            <b>
                                <p>Thể loại: <?php echo $rowRandomGame['category_game']; ?></p>
                                <p>Đồ họa: <?php echo $rowRandomGame['graphics_game']; ?></p>
                            </b>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-10 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">

                <?php
                    //nếu có tài khoản thì hiện phần bình luận
                    if($email_user != "") {
                ?>
                <div class="row"></div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <h3>Viết bình luận</h3>
                    </div>
                </div>
                
                <div class="row"></div>
                    <div class="col-xl-8 col-lg-8 col-md-9 col-sm-12">
                        <form class="form" method="POST" enctype="multipart/form-data">
                            <textarea class="form-control" name="content_comment" placeholder="Viết bình luận ... " id="floatingTextarea2" style="height: 100px;" required></textarea>
                            <br/>
                            <button type="submit" name="submitComment" class="btn btn-primary" style="float: right;">Bình luận</button>
                        </form>
                    </div>
                </div>
                <?php
                    }
                ?>

                <div class="row"></div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <br/>
                        <h3>
                            Bình luận
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                            </svg>
                        </h3>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" style="background-color: #d1e0e0; border-bottom: 2px solid green; border-right: 2px solid green;">
                        <div style="overflow: scroll; -webkit-line-clamp: 10; -webkit-box-orient: vertical; display: -webkit-box;">
                        <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0">
                            <?php 
                                // lỗi ở đây, k cần phải đăng nhập cũng thấy bình luạn
                                // $sqlUserCmt = "SELECT name_user FROM user WHERE email_user = '$email_user'";
                                // $resultUserCmt = mysqli_query($conn, $sqlUserCmt);
                                // $rowUserCmt = mysqli_fetch_array($resultUserCmt);
                            ?>

                            <?php
                                // lấy ra binh luận tương ứng với id_news, sắp xếp theo ngày mới nhất
                                $sqlCmt = "SELECT *, DATEDIFF(DATE(CURDATE()), DATE(date_comment)) AS days_difference
                                            FROM commentposts
                                            WHERE id_news = '$id_news'
                                            GROUP BY date_comment, id_news, content_comment, id_user
                                            HAVING DATEDIFF(DATE(CURDATE()), DATE(date_comment)) >= 0
                                            ORDER BY days_difference ASC";

                                //$sqlCmt = "SELECT * FROM commentposts WHERE id_news = '$id_news'";
                                $resultCmt = mysqli_query($conn, $sqlCmt);
                                if (mysqli_num_rows($resultCmt) > 0) {
                                     
                                    //  số dữ liệu của bảng ... có trong db
                                    echo 'Tổng số bình luận: ' . mysqli_num_rows($resultCmt) . '<br />';
                                    echo '<br/>';
                                    
                                    //  hiển thị dữ liệu ra website
                                    while($row = mysqli_fetch_assoc($resultCmt)) { 
                            ?>

                                <!-- hiện tên người bình luạn -->
                                <h6 style="color: red;">
                                    <?php
                                        $idUserCmd = $row['id_user'];
                                        $sqlUserCmt = "SELECT name_user FROM user WHERE id_user = '$idUserCmd'";
                                        $resultUserCmt = mysqli_query($conn, $sqlUserCmt);
                                        $rowUserCmt = mysqli_fetch_array($resultUserCmt);
                                        echo $rowUserCmt['name_user'];
                                    ?>
                                </h6>

                                <!-- hiện bình luận -->
                                <h6 style="margin-left: 50px; border-left: 3px solid red; padding-left: 5px;">
                                    <?php
                                        echo $row['content_comment'];
                                    ?>
                                </h6>

                                <h6 style="float: right; margin: 20px 20px 0 0;">
                                    <i>
                                        <?php
                                            echo $row['date_comment'];
                                        ?>
                                     </i>
                                </h6>

                                <br/>
                                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">

                            <?php
                                    }
                                } else {
                                    echo '<br/>Chưa có bình luận';
                                }
                            ?>
                            </h6>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- danh sách lựa chọn khác khi đọc xong -->
    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
                <h3>Bài viết khác</h3>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
        </div>
    </div>

    <?php require "../user/paging_news.php"; ?>

        <div class="row justify-content-end" style="text-align: right;">
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12" style="margin: 50px;">
                <nav aria-label="Page navigation example">
                    
                    <ul class="pagination" >
                        <?php 
                            // PHẦN HIỂN THỊ PHÂN TRANG
                            // BƯỚC 7: HIỂN THỊ PHÂN TRANG
                
                            // nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
                            if ($current_page > 1 && $total_page > 1){
                                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="news_detail.php?page='.($current_page - 1).'">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-chevron-double-left" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8.354 1.646a.5.5 0 0 1 0 .708L2.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
                                    <path fill-rule="evenodd" d="M12.354 1.646a.5.5 0 0 1 0 .708L6.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
                                </svg>
                                </a></li>';
                            }
                
                            // Lặp khoảng giữa
                            for ($i = 1; $i <= $total_page; $i++){
                                // Nếu là trang hiện tại thì hiển thị thẻ span
                                // ngược lại hiển thị thẻ a
                                if ($i == $current_page){
                                    echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" style="color: red; border: 1px solid red;" href="news_detail.php?page='.($current_page).'">'.$i.'</a></li> ';
                                }
                                else{
                                    echo ' <li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="news_detail.php?page='.$i.'">'.$i.'</a></li>';
                                }
                            }
                
                            // nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
                            if ($current_page < $total_page && $total_page > 1){
                                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="news_detail.php?page='.($current_page + 1).'">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708z"/>
                                    <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708z"/>
                                </svg>
                                </a></li> ';
                            }
                        ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    

<!-- banner end -->
    <div class="row" style="margin: 5% 0px">>
        <div class="col-lg-12">
            <img style="width: 100%; height: 200px;" src="https://image.freepik.com/free-vector/digital-neon-game-banner_1017-19897.jpg" alt="end game">
        </div>
    </div>


<!-- footer -->
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h3>About Us</h3>
                <p>We bring the most accurate and fastest news possible to you</p>
                <p>Hope what we do can help you in some way.</p>
                <p>Thank you for coming to us</p>
            </div>
            <div class="col-sm-4">
                <h3>Tutorial</h3>
                <p><a href="">Home</a></p>
                <p><a href="">Image game</a></p>
                <p><a href="">News</a></p>
                <p><a href="">Category game</a></p>
            </div>
            <div class="col-sm-4">
                <h3>Contact</h3>
                <p>Email: dovansang2536@gmail.com</p>
                <p>Phone Number: 1234567890</p>
                <p>Group Facebook: news game (null)</p>
            </div>
        </div>
    </div>
</body>
</html>