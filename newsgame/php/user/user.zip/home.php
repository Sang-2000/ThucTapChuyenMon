<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');
    //require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/user/get_userLogin.php');
    

    // news database
    $sqlNews = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
    FROM news
    GROUP BY dateCreate_post, id_news
    HAVING DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) >= 0
    ORDER BY days_difference ASC
    LIMIT 3';
    $resultNews = mysqli_query($conn, $sqlNews);
    $rowNews = mysqli_fetch_assoc($resultNews); // lấy data đầu tiên của câu truy vấn SQL
    // Khi lặp sẽ bỏ qua data này và lấy từ data kế tiếp

    //echo '<br/><br/>id_categoryNews' . $rowNews['id_categoryNews'];


    // news database
    $sqlCateNews = 'SELECT * FROM categorynews';
    $resultCateNews = mysqli_query($conn, $sqlCateNews);
    //$rowCateNews = mysqli_fetch_array($resultCateNews);


    // user database
    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);
    
?>

    <!-- slider start-->
    <div class="container">
        <div class="row" style="margin: 50px 0;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">

                <div id="demo" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">
                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                        <li data-target="#demo" data-slide-to="1"></li>
                        <li data-target="#demo" data-slide-to="2"></li>
                    </ul>

                    <!-- The slideshow -->
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="http://i.imgur.com/gNx0td7.jpg" alt="Los Angeles" width="1100" height="500">
                        </div>
                        <div class="carousel-item">
                            <img src="https://img2.2game.info/re/l/skyrimspecialedition/images/mod/14031/1605681779.jpeg" alt="Chicago" width="1100" height="500">
                        </div>
                        <div class="carousel-item">
                            <img src="https://cdn.tgdd.vn/2020/05/content/bo-hinh-nen-valorant-dep-mat-cho-may-tinh-dien-thoai-game-thu-khong-nen-bo-qua-background-800x450-1.jpg" alt="New York" width="1100" height="500">
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                    </a>
                </div>
 
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-6 col-sm-12 ">
                <h1>TIN MỚI NHẤT</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 ">
            </div>
        </div>

        <div class="row justify-content" style="width: 100%; margin-bottom: 100px;">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 ">
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        
                        <?php

                            if(mysqli_num_rows($resultUserLogin) > 0){
                        ?>
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $rowNews['id_news']; ?>?id_user=<?php echo $rowUserLogin['id_user']; ?>">
                        <!--                             
                                //echo 'id_new =  ' . $rowNews['id_news'] . '<br/>id_user = ' . $rowUserLogin['id_user'];
                            ?> -->

                            <img src="<?php echo $rowNews['urlImage_news']; ?>" style="width: 100%;"  alt="img" >
                            
                            <h3><?php echo $rowNews['title_news']; ?></h3>
                        </a>
                        <?php
                            }
                            else {
                        ?>
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $rowNews['id_news']; ?>?id_categoryNews=<?php echo $rowNews['id_categoryNews']; ?>">
                             <!-- echo 'id: ' . $rowNews['id_news'];?> -->

                            <img src="<?php echo $rowNews['urlImage_news']; ?>" style="width: 100%; height: 400px;"  alt="img" >
                            
                            <h3><?php echo $rowNews['title_news']; ?></h3>
                        </a>
                        <?php
                            }
                        ?>

                    </div>
                </div>    

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <p style="float: right;">
                            <i><?php echo $rowNews['dateCreate_post']; ?></i>
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <p ><?php echo $rowNews['description_news']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class=" col-md-12 col-sm-12">
                        
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-lg-6">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <p style="background-color: darkcyan; border-left: 7px solid red; font-size: 25px; font-weight: 700; text-align: center;">
                            Game ngẫu nhiên
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <br/>
                        <?php 
                            $sqlGame = 'SELECT * FROM games';
                            $resultGame = mysqli_query($conn, $sqlGame);

                            //echo mysqli_num_rows($resultGame) . '<br/>';
                            
                            $random = rand(1, mysqli_num_rows($resultGame)); // lấy ra id
                            //echo $random . '<br/>';

                            $sqlRandomGame = "SELECT * FROM games WHERE id_game = '$random'";
                            $resultRandomGame = mysqli_query($conn, $sqlRandomGame);
                            $rowRandomGame = mysqli_fetch_array($resultRandomGame);
                        ?>

                        <a class="news_post nav-link" href="detail_game.php?id_news=<?php echo $rowRandomGame['id_game']; ?>">
                            <img src="<?php echo $rowRandomGame['urlImage_game']; ?>" style="width: 100%; height: auto;" alt="error">
                            <b>
                                <p style="text-align: center; font-size: 20px;"> <?php echo $rowRandomGame['name_game'] ?></p>
                            </b>
                        </a>
                        <div>
                            <b>
                                <p>Thể loại: <?php echo $rowRandomGame['category_game']; ?></p>
                                <p>Đồ họa: <?php echo $rowRandomGame['graphics_game']; ?></p>
                            </b>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-6 col-sm-12 ">
                <h1>TIN KHÁC</h1>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            
            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 ">
            </div>
        </div>

        <div class="row" style="margin-top: 50px;">
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 ">
                <?php
                    $sql = 'SELECT *, DATEDIFF(DATE(CURDATE()), DATE(dateCreate_post)) AS days_difference
                    FROM news 
                    GROUP BY dateCreate_post, id_news
                    ORDER BY days_difference ASC
                    LIMIT 2, 10';;

                    $query = mysqli_query($conn, $sql);

                    //echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($query) . '<br />';

                    if (mysqli_num_rows($query) > 0) {
                                        
                        //  hiển thị dữ liệu ra website
                        while($row = mysqli_fetch_assoc($query)) {
                ?>

                <div class="row list-3" style=" margin-bottom: 20px;">
                    <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                        <!-- // echo 'id: ' . $row['id_news'];?> -->
                        <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                            
                            <img src="<?php echo $row['urlImage_news']; ?>" style="width: 100%; height: 200px; object-fit: contain;"  alt="img" >
                                            
                        </a>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 ">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                    <a class="news_post nav-link" href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                                    
                                        <b>
                                            <h4><?php echo $row['title_news']; ?></h4>
                                        </b>
                                                    
                                    </a>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                    <p style="text-align: right; font-size: 15px;">
                                        <i>
                                            <?php echo $row['dateCreate_post']; ?>
                                        </i>
                                    </p>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 " style="text-align: justify;">
                                    <h6><?php echo $row['description_news']; ?></h6>
                                </div>
                            </div>
                        
                    </div>
                </div>
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">

                <?php
                        }
                    }
                    else {
                        echo '0 result';
                    }
            
                ?>
            </div>

            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 ">
                <div class="row">
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 ">
                    </div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 ">
                       
                        <nav class="navbar navbar-expand-md " style="text-align: justify;">
                        
                            <ul class="list-group">
                                <li class="list-group-item active" aria-current="true">Bài viết được xem nhiều nhất</li>
                        
                                <?php
                                    $sqlNewsLink = 'SELECT *
                                    FROM news
                                    GROUP BY numberOfReaders_news, id_news, id_categoryNews
                                    ORDER BY numberOfReaders_news DESC
                                    LIMIT 10';

                                    $queryNewsLink = mysqli_query($conn, $sqlNewsLink);

                                    //echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($queryNewsLink) . '<br />';

                                    if (mysqli_num_rows($queryNewsLink) > 0) {
                                                        
                                        //  hiển thị dữ liệu ra website
                                        while($row = mysqli_fetch_assoc($queryNewsLink)) {
                                ?>

                                
                                    <li class="list-group-item">
                                        <a href="news_detail.php?id_news=<?php echo $row['id_news']; ?>">
                                            <?php 
                                                echo $row['title_news'];
                                            ?>
                                        </a>
                                        <br/>
                                        <p style="float: right;">
                                            <i>
                                                Lượt xem: <?php echo $row['numberOfReaders_news']; ?> 
                                            </i>
                                        </p>
                                    </li>
                                
                                <?php
                                        }
                                    }
                                    else {
                                        echo '0 result';
                                    }
                            
                                ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- game -->
    <div class="container">
        <div class="row" style="margin-top: 70px;">
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
                <h1>GAME</h1>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
            </div>
        </div>
        
        <div class="row">
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            </div>
        </div>
    </div>

    <!-- hiển thị dữ liệu game -->
    <div class="container">
        <div class="row">
            <?php
                $sqlGame = "SELECT * FROM games LIMIT 4";
                $resultGame = mysqli_query($conn, $sqlGame);

                if(mysqli_num_rows($resultGame) > 0) {
                    while($row = mysqli_fetch_assoc($resultGame)){
            ?>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="row" style="height: 400px;">
                    
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                        <div class="row " style="height: 300px;;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 game">
                                <a href="detail_game.php?id_game=<?php echo $row['id_game']; ?>">
                                    <img src="<?php echo $row['urlImage_game']; ?>"style="width: 100%; height: 250px;" alt="img game">
                                    <p style="font-size: 20px; font-weight: 700; text-align: center;"><?php echo $row['name_game']; ?></p>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <p><?php echo 'Thể loại: ' . $row['category_game']; ?></p>
                                        <p><?php echo 'Đồ họa: ' . $row['graphics_game']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                    }
                }
                else {
                    
                }
            ?>
        </div>
    </div>