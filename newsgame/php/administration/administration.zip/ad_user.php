<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    $sql = 'SELECT * FROM user';

    if(isset($_POST['searchUser']) && $_POST['searchUser'] != ''){
        $sql = 'SELECT * FROM user WHERE id_user like "%' . $_POST['searchUser'] .'%" or email_user like "%' . $_POST['searchUser'] .'%" or Position_user like "%' . $_POST['searchUser'] .'%" or isBlock_user like "%'. $_POST['searchUser'] .'%" ';
    }
    // 
    
    $result = mysqli_query($conn, $sql);

    
    $sqlAdminMenu = 'SELECT * FROM adminmenu';
    $resultAdminMenu = mysqli_query($conn, $sqlAdminMenu);


    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    //echo 'name user: ' . $rowUserLogin['name_user'];


    // thêm dữ liệu
    if(isset($_POST['submitAddUser'])){
        //$id_user = $_POST['id_user'];
        $name_userAdd = $_POST['name_user'];
        $email_userAdd = $_POST['email_user'];
        $passwordAdd = $_POST['password'];
        $Position_userAdd = $_POST['Position_user'];
        $isBlock_userAdd = $_POST['isBlock_user'];


        if($name_userAdd == ""){echo '"name_user" field cannot be empty.';}
        if($email_userAdd == ""){echo '"email_user" field cannot be empty.';}
        if($passwordAdd == ""){echo '"password" field cannot be empty.';}
        if($Position_userAdd == ""){echo '"Position_user" field cannot be empty.';}
        if($isBlock_userAdd == ""){echo '"isBlock_user" field cannot be empty.';}

        $sqlAdd = "INSERT INTO user(id_user, name_user, email_user, password, Position_user, isBlock_user) 
        VALUES('', '$name_userAdd', '$email_userAdd', '$passwordAdd', '$Position_userAdd', '$isBlock_userAdd')";
        $resultAdd = mysqli_query($conn, $sqlAdd);

        // $url = 'ad_user.php';
        // header('location: ' .$url);
    }
?>

    <style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    
                <?php
                    $sqlCateImg = 'SELECT * FROM categoryimage';
                    $resultCateImg = mysqli_query($conn, $sqlCateImg);
                    //$rowCateNews = mysqli_fetch_array($resultCateNews);

                    if (mysqli_num_rows($resultCateImg) > 0) {
                        //  hiển thị dữ liệu ra website

                ?>
                <div class="row">
                    <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <form class="form form-check" method="POST" enctype="multipart/form-data">

                                            <!-- User id indentity-->
                                            <br/>
                                            
                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm tài khoản</label>
                                            </div>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Tên của bạn là:</label>
                                                <input type="text" name="name_user" class="form-control" id="formGroupExampleInput" placeholder="Nhập vào tên của bạn" required>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Email đăng nhập</label>
                                                <input type="text" name="email_user" class="form-control" id="formGroupExampleInput" placeholder="Nhập vào email" required>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Mật khẩu đăng nhập</label>
                                                <input type="text" name="password" class="form-control" id="formGroupExampleInput" placeholder="Nhạp vào mật khẩu" required>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Chức vụ</label>
                                                <select name="Position_user" class="form-select" aria-label="Default select example">
                                                    <option selected>Mở để chọn</option>
                                                    <option value="Admin">admin</option>
                                                    <option value="User">user</option>
                                                    
                                                </select>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label"> Tài khoản bị khóa không ? </label>
                                                <select name="isBlock_user" class="form-select" aria-label="Default select example">
                                                    <option selected>Mở để chọn</option>
                                                    <option value="Looked">Looked</option>
                                                    <option value="Unlock">Unlock</option>
                                                </select>
                                            </div>

                                            <button type="submit" name="submitAddUser" class="btn btn-primary">Xác nhận thêm</button>

                                            <br>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                    }
                    else {
                        echo '0 result';
                    }
                ?>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchUser" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchUser'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchUser']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <br>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div>
                    <table class="table table-dark table-hover table-bordered" style="text-align: center;">
                        <thead>
                            <tr>
                                <th scope="col">id_user</th>
                                <th scope="col">name_user</th>
                                <th scope="col">email_user</th>
                                <th scope="col">pasword</th>
                                <th scope="col">Position_user</th>
                                <th scope="col">isBlock_user</th>
                                <th scope="col">Sửa </th>
                                <th scope="col">Xóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                

                                 //  lặp hết dữ liệu có trong db
                                if (mysqli_num_rows($result) > 0) {
                                     
                                    //  số dữ liệu của bảng ... có trong db
                                    echo '<p style="background-color: #3385ff; font-weight: 600; font-size: 20px;">Số dữ liệu có trong bảng là ' . mysqli_num_rows($result) . '<br/></p>';
                                    
                                    //  hiển thị dữ liệu ra website
                                    while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <tr>
                                <th scope="row">
                                    <?php echo $row['id_user']; ?>
                                </th>
                                <td>
                                    <?php echo $row['name_user']; ?>
                                </td>
                                <td>
                                    <?php echo $row['email_user']; ?>
                                </td>
                                <td>
                                    <?php echo $row['password']; ?>
                                </td>
                                <td>
                                    <?php echo $row['Position_user']; ?>
                                </td>
                                <td>
                                    <?php echo $row['isBlock_user']; ?>
                                </td>
                                <td>
                                    <a style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_user_update.php?id_user=<?php echo $row['id_user']; ?>">Sửa</a>
                                </td>
                                <td>
                                    <a style="background-color: red; padding: 5px 10px; color: black;" onclick="return remove(<?php echo $row['id_user']; ?>)" href="ad_user_remove.php?id_user=<?php echo $row['id_user']; ?>">Xóa</a>
                                </td>
                            </tr>
                            <?php
                                    }
                                }
                                else {
                                    echo 'Không tìm thấy kết quả';
                                }
        
                                //  đóng kết nối
                                mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <script>
        function remove(id) {
            return confirm('Are you sure you want to delete the id = ' + id + ' element?')
        }
    </script>
</body>

</html>