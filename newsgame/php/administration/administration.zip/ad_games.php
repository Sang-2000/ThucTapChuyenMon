<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    $sql = 'SELECT * FROM games';

    if(isset($_POST['searchGames']) && $_POST['searchGames'] != ''){
        $sql = 'SELECT * FROM games WHERE id_game like "%' . $_POST['searchGames'] .'%" or name_game like "%' . $_POST['searchGames'] .'%" or graphics_game like "%' . $_POST['searchGames'] .'%" or category_game like "%' . $_POST['searchGames'] .'%"';
    }
    
    $result = mysqli_query($conn, $sql);


    $sqlAdminMenu = 'SELECT * FROM adminmenu';
    $resultAdminMenu = mysqli_query($conn, $sqlAdminMenu);


    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    //echo 'name user: ' . $rowUserLogin['name_user'];

    //Thêm dữ liệu vào games
    if(isset($_POST['submitAdd'])){
        //$id_game = $_POST['id_game'];
        $name_game = $_POST['name_game'];
        $category_game = $_POST['category_game'];
        $graphics_game = $_POST['graphics_game'];
        $urlImage_game = $_POST['urlImage_game'];
        $overview_game = $_POST['overview_game'];


        //if($id_categoryNews == ""){echo '"id category News" field cannot be empty.';}
        if($name_game == ""){echo '"name category News" field cannot be empty.';}
        if($category_game == ""){echo '"name category News" field cannot be empty.';}
        if($graphics_game == ""){echo '"name category News" field cannot be empty.';}
        if($overview_game == ""){echo '"name category News" field cannot be empty.';}


        $sqlAdd = "INSERT INTO games(id_game, name_game, category_game, graphics_game, urlImage_game, overview_game) 
        VALUES('', '$name_game', '$category_game', '$graphics_game', '$urlImage_game', '$overview_game')";
        $resultAdd = mysqli_query($conn, $sqlAdd);

        // $url = 'ad_games.php';
        // header('location: ' .$url);
    }
?>

    <style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    
                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                            <form class="form" method="POST" enctype="multipart/form-data">

                                                <br/>
                                                
                                                <div class="mb-3">
                                                    <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm game</label>
                                                </div>

                                                <!-- <div class="mb-3">
                                                    <label for="formGroupExampleInput" class="form-label">Image name</label>
                                                    <input type="text" name="id_categoryNews" class="form-control" id="formGroupExampleInput" placeholder="Enter Category News Id" required>
                                                </div> -->

                                                <br>

                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Tên game</label>
                                                    <input type="text" name="name_game" class="form-control" id="exampleInputPassword1" placeholder="Tên của game" required>
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Thể loại</label>
                                                    <input type="text" name="category_game" class="form-control" id="exampleInputPassword1" placeholder="Thể loại như: game hành động, ..." required>
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Đồ họa game</label>
                                                    <select name="graphics_game" class="form-select" aria-label="Default select example">
                                                        <option selected>Mở đề chọn đồ họa game</option>
                                                        <option value="3D">3D</option>
                                                        <option value="2D">2D</option>
                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Hình ảnh game</label>
                                                    <input type="text" name="urlImage_game" class="form-control" id="exampleInputPassword1" placeholder="Đường dẫn hình ảnh (.jpg, jpec, .png, ...)" required>
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Tổng quan về game</label>
                                                    <textarea class="form-control" name="overview_game" placeholder="Mô tả đôi chút về game" id="floatingTextarea2" style="height: 100px"></textarea>
                                                </div>

                                                <br>

                                                <button type="submit" name="submitAdd" class="btn btn-primary">Xác nhận thêm</button>

                                                <br>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchGames" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchGames'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchGames']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center" style="margin-top: 100px;">
            <div class="col-lg-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <br>
                
                <div>
                    <table class="table table-dark table-hover table-bordered" style="text-align: center;">
                        <thead>
                            <tr>
                                <th scope="col">id_game</th>
                                <th scope="col">name_name</th>
                                <th scope="col">category_game</th>
                                <th scope="col">graphics_game</th>
                                <th scope="col">urrlImage_game</th>
                                <th scope="col">overview_game</th>
                                <th scope="col">Sửa</th>
                                <th scope="col">Xóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                //  số dữ liệu của bảng ... có trong db
                                echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($result) . '<br />';

                                 //  lặp hết dữ liệu có trong db
                                 if (mysqli_num_rows($result) > 0) {
                                    //  hiển thị dữ liệu ra website
                                    while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <tr>
                                <th scope="row">
                                    <?php echo $row['id_game']; ?>
                                </th>
                                <td>
                                    <?php echo $row['name_game']; ?>
                                </td>
                                <td>
                                    <?php echo $row['category_game']; ?>
                                </td>
                                <td>
                                    <?php echo $row['graphics_game']; ?>
                                </td>
                                <td>
                                    <a href="<?php echo $row['urlImage_game']; ?>"><?php echo $row['name_game']; ?></a>
                                </td>
                                <td>
                                    <p style="width: 300px;">
                                       <?php echo $row['overview_game']; ?> 
                                    </p>
                                </td>
                                <td>
                                    <a style="background-color: yellow; padding: 5px 10px; color: black;" style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_games_update.php?id_game=<?php echo $row['id_game']; ?>">Sửa</a>
                                </td>
                                <td>
                                    <a style="background-color: red; padding: 5px 10px; color: black;" onclick="return remove(<?php echo $row['id_game']; ?>)" href="ad_games_remove.php?id_game=<?php echo $row['id_game']; ?>">Xóa</a>
                                </td>
                            </tr>
                            <?php
                                    }
                                }
                                else {
                                    echo '0 result';
                                }
        
                                //  đóng kết nối
                                mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        function remove(id) {
            return confirm('Are you sure you want to delete the id = ' + id + ' element?')
        }
    </script>