<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    // button xác nhận tìm kiếm ảnh
    if(isset($_POST['searchImage']) && $_POST['searchImage'] != ''){
        $sqlSearch = 'SELECT * FROM image WHERE id_categoryImage like "%' . $_POST['searchImage'] .'%" or id_image like "%' . $_POST['searchImage'] .'%" or name_image like "%' . $_POST['searchImage'] .'%"';
        $resultSearch = mysqli_query($conn, $sql);
    }


    //thêm dữ liệu vào image
    if(isset($_POST['submitAdd'])){
        //$id_image = $_POST['id_image'];
        $id_categoryImage = $_POST['id_categoryImage'];
        $name_image = $_POST['name_image'];
        $url_image = $_POST['url_image'];

        if($id_categoryImage == ""){echo '"Image id category" field cannot be empty.';}
        if($name_image == ""){echo '"Image name" field cannot be empty.';}
        if($url_image == ""){echo '"Image URL" field cannot be empty.';}

        $sqlAdd = "INSERT INTO image(id_image, id_categoryImage, name_image, url_image) 
        VALUES('', '$id_categoryImage', '$name_image', '$url_image')";
        $resultAdd = mysqli_query($conn, $sqlAdd);

        // $url = 'ad_index.php';
        // header('location: ' .$url);
    }
?>

<style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                   
                
                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm hình ảnh
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <form class="form" method="POST" enctype="multipart/form-data">

                                            <br>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm hình ảnh</label>
                                            </div>

                                            <br>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Hình ảnh thuộc danh mục</label>
                                                <select name="id_categoryImage" class="form-select" aria-label="Default select example">
                                                    <option selected>Mở để chọn danh mục</option>
                                                    <?php

                                                        $sqlCateImg = 'SELECT * FROM categoryimage';
                                                        $resultCateImg = mysqli_query($conn, $sqlCateImg);

                                                        //  lặp hết dữ liệu có trong db
                                                        if (mysqli_num_rows($resultCateImg) > 0) {
                                                            //  hiển thị dữ liệu ra website
                                                            while($row = mysqli_fetch_assoc($resultCateImg)) { 
                                                    ?>
                                                    
                                                    <option value="<?php echo $row['id_categoryImage'] ?>"> <?php echo $row['id_categoryImage'] . ' - ' . $row['name_categoryImage'] ?> </option>
                                                    <?php
                                                            }
                                                        }
                                                        else {
                                                            echo 'No data';
                                                        }
                                                    ?>
                                                </select>
                                            </div>

                                            <br>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Tên ảnh</label>
                                                <input type="text" name="name_image" class="form-control" id="formGroupExampleInput" placeholder="Enter image name" required>
                                            </div>

                                            <br>

                                            <div class="form-group">
                                                <label for="exampleInputPassword1">URL ảnh</label>
                                                <input type="url" name="url_image" class="form-control" id="exampleInputPassword1" placeholder="Enter image URL" required>
                                            </div>

                                            <br>

                                            <button type="submit" name="submitAdd" class="btn btn-primary">Xác nhận thêm</button>

                                            <br>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchImage" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchImage'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchImage']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <br>
            </div>
        </div>
    </div>

    
    <div class="container">
        <div class="row" style="margin-top: 20px;">
    <?php 
        // PHẦN XỬ LÝ PHP
        // BƯỚC 1: KẾT NỐI CSDL
 
        // BƯỚC 2: TÌM TỔNG SỐ RECORDS
        $result = mysqli_query($conn, 'SELECT COUNT(id_image) AS total FROM image');

        $row = mysqli_fetch_assoc($result);
        $total_records = $row['total']; // tổng số dữ liệu
 
        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
        $current_page = isset($_GET['page']) ? $_GET['page'] : 1; // vị trí trang hiện tại
        $limit = 10; // số dữ liệu tối đa trên 1 page
 
        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
        // tổng số trang
        $total_page = ceil($total_records / $limit);
 
        // Giới hạn current_page trong khoảng 1 đến total_page
        if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
 
        // Tìm Start
        $start = ($current_page - 1) * $limit;
 
        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
        $result = mysqli_query($conn, "SELECT * FROM image LIMIT $start, $limit");
 
     ?>

    <div>
        <table class="table table-dark table-hover table-bordered" style="text-align: center;">
            <thead>
                <tr>
                    <th scope="col">id_image</th>
                    <th scope="col">id_categoryImage</th>
                    <th scope="col">name_image</th>
                    <th scope="col">url_image</th>
                    <th scope="col">image</th>
                    <th scope="col">Sửa </th>
                    <th scope="col">Xóa</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                     //  số dữ liệu của bảng ... có trong db
                    echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($result) . '<br />';

                    //  lặp hết dữ liệu có trong db
                    if (mysqli_num_rows($result) > 0) {
                    //  hiển thị dữ liệu ra website
                    while($row = mysqli_fetch_assoc($result)) { 
                ?>
                <tr>
                    <th scope="row">
                        <?php echo $row['id_image']; ?>
                    </th>
                    <td>
                        <?php echo $row['id_categoryImage']; ?>
                    </td>
                    <td>
                        <?php echo $row['name_image']; ?>
                    </td>
                    <td>
                        <a href="<?php echo $row['url_image']; ?>">
                            <?php echo $row['url_image']; ?>
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo $row['url_image']; ?>">
                            <img style="width: 100px; height 100px;" src="<?php echo $row['url_image']; ?>">
                        </a>
                    </td>
                    <td>
                        <a style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_image_update.php?id_image=<?php echo $row['id_image']; ?>">Sửa</a>
                       </td>
                    <td>
                        <a style="background-color: red; padding: 5px 10px; color: black;" onclick="return remove(<?php echo $row['id_image']; ?>)" href="ad_image_remove.php?id_image=<?php echo $row['id_image']; ?>">Xóa</a>
                    </td>
                    </tr>
                        <?php
                                }
                            }
                            else {
                                echo '0 result';
                            }
        
                        ?>
                </tbody>
            </table>
        </div>
    </div>



    <div class="container">
        <div class="row justify-content-begin">
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                <nav aria-label="Page navigation example" style="left: 0; bottom: 0; margin: 20px; position: fixed; z-index: 100000;">
                    <p style="color: red; font-size: 20px;">
                        Mục trang
                    </p>
                    <ul class="pagination">
                        <?php 
                            // PHẦN HIỂN THỊ PHÂN TRANG
                            // BƯỚC 7: HIỂN THỊ PHÂN TRANG
                
                            // nếu current_page > 1 và total_page > 1 mới hiển thị nút prev
                            if ($current_page > 1 && $total_page > 1){
                                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="ad_image.php?page='.($current_page - 1).'">Prev</a></li>';
                            }
                
                            // Lặp khoảng giữa
                            for ($i = 1; $i <= $total_page; $i++){
                                // Nếu là trang hiện tại thì hiển thị thẻ span
                                // ngược lại hiển thị thẻ a
                                if ($i == $current_page){
                                    echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" style="color: red; border: 1px solid red;" href="ad_image.php?page='.($current_page).'">'.$i.'</a></li> ';
                                }
                                else{
                                    echo ' <li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="ad_image.php?page='.$i.'">'.$i.'</a></li>';
                                }
                            }
                
                            // nếu current_page < $total_page và total_page > 1 mới hiển thị nút prev
                            if ($current_page < $total_page && $total_page > 1){
                                echo '<li class="page-item" style="margin: 0px 2px;"><a class="page-link" href="ad_image.php?page='.($current_page + 1).'">Next</a></li> ';
                            }
                        ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    
    <script>
        function remove(id) {
            return confirm('Bạn chắc chắn muốn xóa hình ảnh có id = ' + id + ' ?')
        }
    </script>