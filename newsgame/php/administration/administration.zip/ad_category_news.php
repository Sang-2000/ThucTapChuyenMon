<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    $sql = 'SELECT * FROM categorynews';

    if(isset($_POST['searchCategoryNews']) && $_POST['searchCategoryNews'] != ''){
        $sql = 'SELECT * FROM categorynews WHERE id_categoryNews like "%' . $_POST['searchCategoryNews'] .'%" or name_categoryNews like "%' . $_POST['searchCategoryNews'] .'%"';
    }
    
    $result = mysqli_query($conn, $sql);


    $sqlAdminMenu = 'SELECT * FROM adminmenu';
    $resultAdminMenu = mysqli_query($conn, $sqlAdminMenu);


    if(isset($_GET['id_user'])){
        $id_user = $_GET['id_user'];
    }
    else {
        $id_user = null;
    }
    $sqlUserLogin = "SELECT * FROM user WHERE id_user = '$id_user'";
    $resultUserLogin = mysqli_query($conn, $sqlUserLogin);
    $rowUserLogin = mysqli_fetch_array($resultUserLogin);

    //echo 'name user: ' . $rowUserLogin['name_user'];


    // thêm dữ liệu categoryNews
    if(isset($_POST['submitAdd'])){
        //$id_categoryNews = $_POST['id_categoryNews'];
        $name_categoryNews = $_POST['name_categoryNews'];
        $link_categoryNews = $_POST['link_categoryNews'];

        //if($id_categoryNews == ""){echo '"id category News" field cannot be empty.';}
        if($name_categoryNews == ""){echo 'Không được bỏ trống trường nầy.';}
        if($link_categoryNews == ""){echo 'Không được bỏ trống trường nầy.';}

        $sqlAdd = "INSERT INTO categorynews(id_categoryNews, name_categoryNews, link_categoryNews) 
        VALUES('', '$name_categoryNews', '$link_categoryNews')";
        $resultAdd = mysqli_query($conn, $sqlAdd);

        // $url = 'ad_category_news.php';
        // header('location: ' .$url);
    }
?>


    <style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    
                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <form class="form" method="POST" enctype="multipart/form-data">

                                            <br/>
                                            
                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm danh mục bài viết</label>
                                            </div>

                                            <!-- <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Image name</label>
                                                <input type="text" name="id_categoryNews" class="form-control" id="formGroupExampleInput" placeholder="Enter Category News Id" required>
                                            </div> -->

                                            <br>

                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Tên danh mục</label>
                                                <input type="text" name="name_categoryNews" class="form-control" id="exampleInputPassword1" placeholder="Nhập vào tên danh mục" required>
                                            </div>

                                            <br>

                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Đường dẫn đến danh mục</label>
                                                <input type="text" name="link_categoryNews" class="form-control" id="exampleInputPassword1" placeholder="Nhập vào file .php" required>
                                            </div>

                                            <br>

                                            <button type="submit" name="submitAdd" class="btn btn-primary">Xác nhận thêm</button>

                                            <br>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchCategoryNews" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchCategoryNews'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchCategoryNews']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center" style="margin-top: 100px;">
            <div class="col-lg-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <hr>
                
                <div>
                    <table class="table table-dark table-hover table-bordered" style="text-align: center;">
                        <thead>
                            <tr>
                                <th scope="col">id_categoryNews</th>
                                <th scope="col">name_categoryNews</th>
                                <th scope="col">link_categoryNews</th>
                                <th scope="col">Sửa </th>
                                <th scope="col">Xóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                //  số dữ liệu của bảng ... có trong db
                                echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($result) . '<br />';

                                 //  lặp hết dữ liệu có trong db
                                 if (mysqli_num_rows($result) > 0) {
                                    //  hiển thị dữ liệu ra website
                                    while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <tr>
                                <th scope="row">
                                    <?php echo $row['id_categoryNews']; ?>
                                </th>
                                <td>
                                    <?php echo $row['name_categoryNews']; ?>
                                </td>
                                <td>
                                    <?php echo $row['link_categoryNews']; ?>
                                </td>
                                <td>
                                    <a style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_category_news_update.php?id_categoryNews=<?php echo $row['id_categoryNews']; ?>">Sửa</a>
                                </td>
                                <td>
                                    <a style="background-color: red; padding: 5px 10px; color: black;" onclick="return remove(<?php echo $row['id_categoryNews']; ?>)"  href="ad_category_news_remove.php?id_categoryNews=<?php echo $row['id_categoryNews']; ?>">Xóa</a>
                                </td>
                            </tr>
                            <?php
                                    }
                                }
                                else {
                                    echo '0 result';
                                }
        
                                //  đóng kết nối
                                mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function remove(id) {
            return confirm('Bạn chắc chắn muỗn xóa danh mục bài viết với id = ' + id + ' ?')
        }
    </script>
</body>

</html>