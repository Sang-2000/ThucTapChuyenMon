<?php 
    require_once('D:/DOWNLOAD/New folder/htdocs/newsgame/php/connect/connect.php');

    // menu tự dộng của admin
    $sqlAdminMenu = 'SELECT * FROM adminmenu';
    $resultAdminMenu = mysqli_query($conn, $sqlAdminMenu);


    // thêm dữ liệu
    if(isset($_POST['submitAdd'])){
        //$id_categoryImage = $_POST['id_categoryImage'];
        $name_categoryImage = $_POST['name_categoryImage'];
        $urlImage_categoryImage = $_POST['urlImage_categoryImage'];
        $description_categoryImage = $_POST['description_categoryImage'];

        //if($id_categoryImage == ""){echo '"id category News" field cannot be empty.';}
        if($name_categoryImage == ""){echo 'không được bỏ trống trường này';}
        if($urlImage_categoryImage == ""){echo 'không được bỏ trống trường này';}
        if($description_categoryImage == ""){echo 'không được bỏ trống trường này';}

        // câu lệnh thêm sql
        $sql = "INSERT INTO categoryimage(id_categoryImage, name_categoryImage, urlImage_categoryImage, description_categoryImage) 
        VALUES('', '$name_categoryImage', '$urlImage_categoryImage', '$description_categoryImage')";
        $result = mysqli_query($conn, $sql);
    }


    // tìm kiếm
    if(isset($_POST['searchCategoryImage']) && $_POST['searchCategoryImage'] != ''){
        $sql = 'SELECT * FROM categoryimage WHERE id_categoryImage like "%' . $_POST['searchCategoryImage'] .'%" or name_categoryImage like "%' . $_POST['searchCategoryImage'] .'%"';
    }


    // truy vấn cơ sở dữ liệu gốc
    $sql = 'SELECT * FROM categoryimage';

    
    // kết nối đến sql
    $result = mysqli_query($conn, $sql);

?>

    <style>
        .accordion {
            background-color: #eee;
            color: #444;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .active, .accordion:hover {
            background-color: #80ffe5; 
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: white;
            overflow: hidden;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center" style="margin: 50px 0px 10px 0px;">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    
                <?php
                    $sqlCateImg = 'SELECT * FROM categoryimage';
                    $resultCateImg = mysqli_query($conn, $sqlCateImg);
                    //$rowCateNews = mysqli_fetch_array($resultCateNews);

                    if (mysqli_num_rows($resultCateImg) > 0) {
                        //  hiển thị dữ liệu ra website

                ?>
                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                        <div class="row" style="margin-top: 20px;">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                                <button class="accordion">
                                    Nhấn vào để thêm
                                </button>

                                <div class="panel">
                                    <div class="row">
                                        <form class="form form-check"  method="POST" enctype="multipart/form-data">
                                            
                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" style="font-size: 35px;">Thêm danh mục hình ảnh</label>
                                            </div>
                                            

                                            <!-- <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label" >Nhập vào id</label>
                                                <input type="text" name="id_categoryImage" class="form-control" id="formGroupExampleInput" placeholder="Không cần thiết phải nhập" required>
                                            </div> -->

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Tên danh mục</label>
                                                <input type="text" name="name_categoryImage" class="form-control" id="formGroupExampleInput" placeholder="Nhập vào tên danh mục" required>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Đường dẫn ảnh</label>
                                                <input type="text" name="urlImage_categoryImage" class="form-control" id="formGroupExampleInput" placeholder="Nhập vào đường dẫn hình ảnh (.png, .jpeg, ...)" required>
                                            </div>

                                            <br/>

                                            <div class="mb-3">
                                                <label for="formGroupExampleInput" class="form-label">Mô tả danh mục</label>
                                                <input type="text" name="description_categoryImage" class="form-control" id="formGroupExampleInput" placeholder="Nhập vào mô tả danh mục" required>
                                            </div>

                                            <br/>

                                            <button type="submit" name="submitAdd" class="btn btn-primary">Xác nhận thêm</button>

                                            <br/>
                                            <br/>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                    }
                    else {
                        echo '0 result';
                    }
                ?>
            </div>

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.display === "block") {
                            panel.style.display = "none";
                        } else {
                            panel.style.display = "block";
                        }
                    });
                }
            </script>

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <p>Tìm kiếm dữ liệu</p>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-inline" method="POST">
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="inputPassword2" class="sr-only">Nhập từ khóa</label>
                                <input type="tect" name="searchCategoryImage" class="form-control" id="inputPassword2" placeholder="Nhập từ khóa">
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <br/>

                    <?php if(isset($_POST['searchCategoryImage'])) {?>
                    <p><?php echo 'Từ khóa tìm kiếm: ' . $_POST['searchCategoryImage']; ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    

    <div class="container">
        <div class="row" style="margin-top: 100px;">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <hr style="height: 2px; border-width: 0; color: gray; background-color: gray;">
                <h3>Dữ liệu</h3>
                <br>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center" style="margin-top: 100px;">
            <div class="col-lg-12">
                <div>
                    <table class="table table-dark table-hover table-bordered" style="text-align: center;">
                        <thead>
                            <tr>
                                <th scope="col">id_categoryImage</th>
                                <th scope="col">name_categoryImage</th>
                                <th scope="col">urlImage_categoryImage</th>
                                <th scope="col">description_categoryImage</th>
                                <th scope="col">Sửa </th>
                                <th scope="col">Xóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                //  số dữ liệu của bảng ... có trong db
                                echo 'Số dữ liệu có trong bảng là ' . mysqli_num_rows($result) . '<br />';

                                 //  lặp hết dữ liệu có trong db
                                 if (mysqli_num_rows($result) > 0) {
                                    //  hiển thị dữ liệu ra website
                                    while($row = mysqli_fetch_assoc($result)) {
                                        $i = $row['id_categoryImage'];
                            ?>
                            <tr>
                                <th scope="row">
                                    <?php echo $row['id_categoryImage']; ?>
                                </th>
                                <td>
                                    <?php echo $row['name_categoryImage']; ?>
                                </td>
                                <td>
                                    <a href="<?php echo $row['urlImage_categoryImage']; ?>">
                                        <img src="<?php echo $row['urlImage_categoryImage']; ?>" alt="error imagr" style="width: 100px; height: 100px;">
                                    </a>
                                    
                                </td>
                                <td>
                                    <?php echo $row['description_categoryImage']; ?>
                                </td>
                                <td>
                                    <a style="background-color: yellow; padding: 5px 10px; color: black;" href="ad_category_news_update.php?id_categoryImage= echo $row['id_categoryImage']; ?>">Sửa</a>
                                </td>
                                <td>
                                    <a style="background-color: red; padding: 5px 10px; color: black;" onclick="return remove(<?php echo $row['id_categoryImage']; ?>)" href="ad_category_news_remove.php?id_categoryImage=<?php echo $row['id_categoryImage']; ?>">Xóa</a>
                                </td>
                            </tr>
                            <?php
                                    }
                                }
                                else {
                                    echo '0 result';
                                }
        
                                //  đóng kết nối
                                mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    
    <script>
        function remove(id) {
            return confirm('Are you sure you want to delete the id = ' + id + ' element?')
        }
    </script>
</body>

</html>